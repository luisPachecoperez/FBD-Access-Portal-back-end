import * as express from 'express';
import { graphqlHTTP } from 'express-graphql';
import schema from './infrastructure/graphql/schemas';
import { rootResolvers } from './infrastructure/graphql/rootResolvers';
import * as cookieParser from 'cookie-parser';

// Importa cors así (con * as)
import * as cors from 'cors';

const app = express();

app.use(cors.default ? cors.default({
  origin: 'http://localhost:4200',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true,
}) : cors({
  origin: 'http://localhost:4200',
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true,
}));

app.use(express.json());
app.use(cookieParser.default ? cookieParser.default() : cookieParser());

app.use('/graphql', graphqlHTTP({
  schema,
  rootValue: rootResolvers,
  graphiql: true,
}));

app.listen(4000, () => {
  console.log('🚀 Servidor corriendo en http://localhost:4000/graphql');
});

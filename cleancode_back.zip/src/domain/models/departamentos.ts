// src/domain/models/Beneficiario.ts
export class Departamento {
    constructor(
      public id: String,
      public nombre: String,
      public codigo_dane: String,
      public pais_id: String,
    ) {}
  }
   
// src/domain/models/Beneficiario.ts
export class Municipio {
    constructor(
      public id: String,
      public nombre: String,
      public codigo_dane: String,
      public departamento_id: String,
    ) {}
  }
  
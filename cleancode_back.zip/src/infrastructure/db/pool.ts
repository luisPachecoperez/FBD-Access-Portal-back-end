import { Pool } from 'pg';
import * as dotenv from 'dotenv'; // ✅ Esto es lo correcto
dotenv.config();


console.log('DB_HOST', process.env.DB_HOST);
export const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  
});